class User {
  String name;
  String nickname;
  String tel;
  String birth;
  String email;

  User({
    this.name = "eva",
    this.nickname = "Muster",
    this.tel = "0176 987564",
    this.birth = "10.11.1990",
    this.email = "example@mail.com",
  });
}
