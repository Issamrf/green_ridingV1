import 'dart:async';
import 'dart:ui' as ui;
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'directionRepo.dart';

class ShowPath extends StatefulWidget {
  @override
  State<StatefulWidget> createState() => ShowPathState();
}

class ShowPathState extends State<ShowPath> {
  @override
  void initState() {
    super.initState();

    getlocations();
  }

  var directions;
  bool isloading = false;
  getlocations() async {
    setState(() {
      isloading = true;
    });
    await DirectionsRepository().getDirections().then((value) async => {
          directions = value,
          print("my directionss are $directions"),
        });
    setState(() {
      isloading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: isloading
          ? Center(
              child: CircularProgressIndicator(),
            )
          : Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                SizedBox(
                  height: 10,
                ),
                Container(
                  height: 5,
                  width: 100,
                  color: Colors.grey,
                ),
                SizedBox(
                  height: 10,
                ),
                Text(
                  'Trip Schedule',
                  style: TextStyle(
                      color: Color(0xff90bc5a),
                      fontSize: 24,
                      fontWeight: FontWeight.bold),
                ),
                ListView.builder(
                  shrinkWrap: true,
                  itemCount: directions['segments'].length,
                  itemBuilder: (context, i) => Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          "${directions['segments'][i]['start_time'].toString().split("T")[1].toString().split(".")[0]} " +
                              " ${directions['segments'][i]['start']}",
                          style: TextStyle(
                            //color: Colors.green,
                            fontSize: 15,
                          ),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Row(
                          children: [
                            Icon(
                              directions['segments'][i]['vehicletype'] == "bus"
                                  ? Icons.directions_bus_filled_outlined
                                  : Icons.directions_car_filled_outlined,
                              color: Color(0xff90bc5a),
                            ),
                            Text(
                              "${directions['segments'][i]['vehicleid'].toString()}",
                              style: TextStyle(
                                //color: Colors.green,
                                fontSize: 15,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Text(
                            "${directions['segments'][i]['end_time'].toString().split("T")[1].toString().split(".")[0]} " +
                                " ${directions['segments'][i]['end']}",
                            style: TextStyle(
                              //color: Colors.green,
                              fontSize: 15,
                            )),
                        SizedBox(
                          height: 7,
                        ),
                      ],
                    ),
                  ),
                )
              ],
            ),
    );
  }
}
